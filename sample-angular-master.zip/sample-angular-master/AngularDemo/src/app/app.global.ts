import { Injectable } from "@angular/core";


@Injectable()

export class GlobalConstants {

    public static API_BASE_URL: string = 'http://localhost:54594/api/';
}
