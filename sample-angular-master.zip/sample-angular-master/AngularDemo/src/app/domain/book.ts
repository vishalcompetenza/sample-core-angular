export interface Book {
    id,
    name,
    authors,
    numberOfPages,
    dateOfPublication: Date,
}
